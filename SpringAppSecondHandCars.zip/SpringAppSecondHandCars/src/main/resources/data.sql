delete from Car;
delete from Car_Info;
delete from Seller;

insert into Car (brand, model)
    values ('Audi', 'A4');
insert into Car (brand, model)
    values ('Audi', 'A6');
insert into Car (brand, model)
    values ('Audi', 'A8');
insert into Car (brand, model)
    values ('BMW', '3');
insert into Car (brand, model)
    values ('BMW', '5');
insert into Car (brand, model)
    values ('BMW', '7');
insert into Car (brand, model)
    values ('CHEVROLET', 'CRUZE');
insert into Car (brand, model)
    values ('CHEVROLET', 'AVEO');
insert into Car (brand, model)
    values ('CITROEN', 'C4');
insert into Car (brand, model)
    values ('CITROEN', 'C5');
insert into Car (brand, model)
    values ('CITROEN', 'BERLINGO');
insert into Car (brand, model)
    values ('FORD', 'FOCUS');
insert into Car (brand, model)
    values ('FORD', 'KUGA');
insert into Car (brand, model)
    values ('HONDA', 'CIVIC');
insert into Car (brand, model)
    values ('HONDA', 'ACCORD');
insert into Car (brand, model)
    values ('HONDA', 'CRV');
insert into Car (brand, model)
    values ('HYUNDAI', 'I30');
insert into Car (brand, model)
    values ('HYUNDAI', 'IX35');
insert into Car (brand, model)
    values ('KIA', 'RIO');
insert into Car (brand, model)
    values ('KIA', 'CEED');
insert into Car (brand, model)
    values ('KIA', 'SPORTAGE');
insert into Car (brand, model)
    values ('MAZDA', '6');
insert into Car (brand, model)
    values ('MAZDA', 'CX5');
insert into Car (brand, model)
    values ('OPEL', 'ASTRA');
insert into Car (brand, model)
    values ('OPEL', 'ZAFIRA');
insert into Car (brand, model)
    values ('TOYOTA', 'CAMRY');
insert into Car (brand, model)
    values ('TOYOTA', 'RAV4');
insert into Car (brand, model)
    values ('VOLVO', 'S60');
insert into Car (brand, model)
    values ('VOLVO', 'S80');
