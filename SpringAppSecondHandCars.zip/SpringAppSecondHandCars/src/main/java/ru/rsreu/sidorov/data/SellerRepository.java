package ru.rsreu.sidorov.data;

import org.springframework.data.repository.CrudRepository;
import ru.rsreu.sidorov.models.Seller;

public interface SellerRepository extends CrudRepository<Seller, Long> {
    Seller findById(long sellerId);
}
