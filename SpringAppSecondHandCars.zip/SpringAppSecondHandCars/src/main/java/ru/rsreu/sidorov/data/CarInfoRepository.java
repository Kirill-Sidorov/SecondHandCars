package ru.rsreu.sidorov.data;

import org.springframework.data.repository.CrudRepository;
import ru.rsreu.sidorov.models.CarInfo;

public interface CarInfoRepository extends CrudRepository<CarInfo, Long> {
}
