package ru.rsreu.sidorov.models;

import lombok.Data;

@Data
public class Car {

    private String brand;
    private String model;

}
